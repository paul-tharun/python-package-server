def test_func_state():
	print("This is a test func")
