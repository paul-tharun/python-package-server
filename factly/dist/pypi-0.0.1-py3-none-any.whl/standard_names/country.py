def test_func_country():
	print("This is a test func country")
